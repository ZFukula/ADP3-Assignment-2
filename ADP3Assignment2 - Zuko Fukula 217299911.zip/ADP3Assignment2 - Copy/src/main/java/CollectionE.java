/**
 * Zuko Fukula 217299911
 * Collection add,remove,find
 */

import java.util.ArrayList;
import java.util.Collection;

public class CollectionE {

    public static void main(String[] args) {

        boolean find = false;

        //add
        {
            Collection names = new ArrayList();
            names.add("James");
            names.add("Joey");
            names.add("Layla");
            names.add("Chloe");

            //remove
            names.remove("Joey");

            //find
           if (names.contains("Rob")) {
               find = true;
           }
            else{
                find = false;

           }
            System.out.println(names);
            System.out.println(find);
        }
    }
}


