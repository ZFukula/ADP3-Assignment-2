/**
 * Zuko Fukula 217299911
 * Set add,remove,find
 */
import java.util.*;

public class SetE {

    public static void main(String[] args){

        boolean found = false;
//add

        Set<String> employeeNames = new HashSet<>();
        employeeNames.add("Magda");
        employeeNames.add("Josephine");
        employeeNames.add("Clive");

//remove
        employeeNames.remove("Josephine");

//find

        if (employeeNames.contains("Clive")) {
            found = true;
        }
            else{
            found = false;

        }

        System.out.println(employeeNames);
        System.out.println(found);

    }
}
