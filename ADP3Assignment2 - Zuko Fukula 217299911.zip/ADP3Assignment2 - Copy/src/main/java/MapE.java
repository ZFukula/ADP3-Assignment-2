/**
 * Zuko Fukula 217299911
 * Map add,remove,find
 */


import java.util.*;

public class MapE {

    public static void main(String[] args) {

        boolean found = false;
//add
        Map<Integer, String> mapLocation = new HashMap<>();
        mapLocation.put(2345, "Colarado");
        mapLocation.put(2347, "Kansas");

        //find

        if (mapLocation.containsValue("Colarado")) {
            found = true;
        }

        else{
            found = false;
        }

        String removedKey = mapLocation.remove(2347);
//remove
        if (removedKey != null) {
            System.out.println("Removed key: " + removedKey);
        }
        System.out.println(mapLocation);
        System.out.println(found);

    }
}

