/**
 * Zuko Fukula 217299911
 * List add,remove,find
 */


import java.util.*;


public class ListE {

    public static void main(String[] args) {

        boolean found = false;

        List<String> linkedPlaces = new LinkedList<>();

        //add
        linkedPlaces.add("Cape Town");
        linkedPlaces.add("George");
        linkedPlaces.add("Simon's Town");
        linkedPlaces.add("Knysna");

        //remove
        linkedPlaces.remove("George");

        //find
        if (linkedPlaces.contains("Knysna")) {
            found = true;
        }
        else{
            found = false;

        }

        System.out.println(linkedPlaces);
        System.out.println(found);



    }
}
